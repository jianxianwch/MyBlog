package com.unionpay.thriftServer;

import org.apache.thrift.TException;

public class HelloWorldImpl implements HelloWorldService.Iface{
	
	public HelloWorldImpl() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public String sayHello(String username) throws TException {
		// TODO Auto-generated method stub
		return "Hello " + username + " welcome to the thrift's world!";
	}

}
