package com.unionpay.thriftServer;

import org.apache.thrift.protocol.TBinaryProtocol;
import org.apache.thrift.server.TServer;
import org.apache.thrift.server.TThreadPoolServer;
import org.apache.thrift.transport.TServerSocket;
import org.apache.thrift.transport.TServerTransport;

public class HelloServiceDemo2 {
	
	public static int SERVICE_PORT = 8090;
	
	public void startService(){
		try{
			System.out.println("HelloWorld TThreadPoolServer Start...");
			
			HelloWorldService.Processor<HelloWorldService.Iface> tprocessor = new HelloWorldService.Processor<HelloWorldService.Iface>(new HelloWorldImpl());
			
			TServerTransport tServerTransport = new TServerSocket(SERVICE_PORT);
			
			TThreadPoolServer.Args args = new TThreadPoolServer.Args(tServerTransport);
			
			args.processor(tprocessor);
			
			args.protocolFactory(new TBinaryProtocol.Factory());
			
			TServer service = new TThreadPoolServer(args);
			
			service.serve();
			
			
		}catch(Exception e){
			
			System.out.println("Service start error!");
			e.printStackTrace();
			
		}
	}
	
	public static void main(String[] args){
		HelloServiceDemo2  server = new HelloServiceDemo2();
		server.startService();
	}

}
