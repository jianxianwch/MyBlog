package com.unionpay.thriftServer;

import org.apache.thrift.protocol.TCompactProtocol;
import org.apache.thrift.server.TServer;
import org.apache.thrift.server.TSimpleServer;
import org.apache.thrift.transport.TServerSocket;
import org.apache.thrift.transport.TServerTransport;

public class HelloServerDemo {
	
	//定义服务端口号
	public static final int SERVER_PORT = 8090;
	
	public static void main(String[] args){
		HelloServerDemo service = new HelloServerDemo();
		service.startServer();
	}
	
	public void startServer(){
		try{
			System.out.println("HelloWorld TSimpleServer start...");
			
		/*	thrift Processor 业务逻辑处理层
			创建Processor，HelloWorldImpl 实现类作为参数传入Processor构造方法里
			processor主要完成的事情：
			1.把idl里定义的方法进行封装，最终暴露出一个统一的接口给thrift server进行调用
			2.封装protocol和transport层，包括输入输出流的处理细节、序列化反序列化*/			
			HelloWorldService.Processor<HelloWorldService.Iface> tprocessor = new HelloWorldService.Processor<HelloWorldService.Iface>(new HelloWorldImpl());
			
			//创建TServerTransport
			TServerTransport serverTransport = new TServerSocket(SERVER_PORT);
			TServer.Args tArgs = new TServer.Args(serverTransport);
			tArgs.processor(tprocessor);
			//创建TProtocol
			tArgs.protocolFactory(new TCompactProtocol.Factory());
			//创建TServer
			TServer server = new TSimpleServer(tArgs);
			//启动TServer
			server.serve();
		}catch(Exception e){
			System.out.println("Server start error!");
			e.printStackTrace();
		}
	}
}
