package com.unionpay.thriftClient;

import org.apache.thrift.TException;
import org.apache.thrift.protocol.TBinaryProtocol;
import org.apache.thrift.protocol.TProtocol;
import org.apache.thrift.transport.TSocket;
import org.apache.thrift.transport.TTransport;
import org.apache.thrift.transport.TTransportException;

public class HelloClientDemo2 {
	
	public static String SERVICE_IP = "localhost";
	public static int SERVICE_PORT = 8090;
	public static int TIMEOUT = 30000;
	
	public void startServer(String userName){
		TTransport ttransport= null;
		try{
			ttransport = new TSocket(SERVICE_IP,SERVICE_PORT,TIMEOUT);
			TProtocol tprotocol = new TBinaryProtocol(ttransport);
			HelloWorldService.Client client = new HelloWorldService.Client(tprotocol);
			
			ttransport.open();
			
			String result = client.sayHello(userName);
			System.out.println("Thrift Client result: " + result);
		}catch(TTransportException e){
			e.printStackTrace();
		}catch(TException e){
			e.printStackTrace();
		}finally{
			if(ttransport!=null){
				ttransport.close();
			}
		}
	}
	
	public static void main(String[] args){
		HelloClientDemo2 client = new HelloClientDemo2();
		client.startServer("jxwch");
	}
}
