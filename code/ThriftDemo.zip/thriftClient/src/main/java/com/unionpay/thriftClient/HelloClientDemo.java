package com.unionpay.thriftClient;

import org.apache.thrift.TException;
import org.apache.thrift.protocol.TCompactProtocol;
import org.apache.thrift.protocol.TProtocol;
import org.apache.thrift.transport.TSocket;
import org.apache.thrift.transport.TTransport;
import org.apache.thrift.transport.TTransportException;

/**
 * @author jxwch 
 * @date 2017.01.17
 *
 */
public class HelloClientDemo {
	
	//定义Socket服务参数
	public static final String SERVER_IP = "localhost";
	public static final int SERVER_PORT = 8090;
	public static final int TIMEOUT = 30000;
	

	public static void main(String[] args){
		HelloClientDemo client = new HelloClientDemo();
		client.startClient("jxwch");
	}
	
	public void startClient(String userName){
		
		
		TTransport transport = null;
		try{
			//创建TTransport
			transport = new TSocket(SERVER_IP, SERVER_PORT, TIMEOUT);
			//创建TProtocol
			TProtocol protocol = new TCompactProtocol(transport);
			//创建Client
			HelloWorldService.Client client = new HelloWorldService.Client(protocol);
			//启动TTransport
			transport.open();
			
			//调用client中封装的方法
			String result = client.sayHello(userName);
			System.out.println("Thrift Client result: " + result);
		}catch(TTransportException e){
			e.printStackTrace();
		}catch(TException e){
			e.printStackTrace();
		}finally{
			if(null != transport){
				transport.close();
			}
		}
	}
}
